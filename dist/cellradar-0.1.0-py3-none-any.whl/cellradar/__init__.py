"""
Created on Sat Aug 10 11:36:11 2024
@author: mcanela
"""

from main import *
from predicting import *
from segmentation import *
from training import *
from utils import *
